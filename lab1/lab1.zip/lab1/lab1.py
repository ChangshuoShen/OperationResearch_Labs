import numpy as np
import random
import time
import matplotlib.pyplot as plt
import matplotlib

# 指定默认字体
matplotlib.rcParams['font.family'] = 'SimHei'  # 或其他支持中文的字体
matplotlib.rcParams['axes.unicode_minus'] = False  # 解决负号'-'显示为方块的问题

random.seed(42)
# global variables
No_feasible_solution = 0
No_unbounded_solution = 0

# 模块0：转换标准形式  但是好像也用不到,那就先不写
def convert_to_standard_form(c, A, b):
    """
    
    """
    index = []
    for i in range(len(b)):
        if np.all(A[i,:]==0):
            index.append(i)
    A = np.delete(A, index, axis=0)
    b = np.delete(b, index, axis=0)
    return c, A, b

# 模块1：检查A是否行满秩，移除多余的约束， 这里检查(A,b)是否满秩
def remove_redundant_constraints(A, b): 
    """
    检查并移除冗余约束，返回去冗余后的 A 和 b
    使用方法2，但方法2真的行吗
    """
    A = np.column_stack((A,b))
    # print(A)
    q,r = np.linalg.qr(A.T)
    index = np.abs(np.diag(r ) )> 1e-6 # 得到正常的数组
    B = (A.T[:,index]).T
    return B[:,:-1], B[:,-1]  # 直接也解决了系数全为0的问题

# 模块2：初始化可行基解：大M法
def initialize_feasible_solution(A, b, c):
    """
    使用大M法初始化一个可行基解
    """
    m, n = A.shape
    M = max((np.abs(c)).max()*1e5,1e6) # 动态调整M的值
    artificial_vars = np.eye(m) # 人工变量的系数
    
    # 增加人工变量
    A_aug = np.hstack([A, artificial_vars])
    c_aug = np.hstack([c, M * np.ones(m)])

    # 初始化人工变量
    x1 = np.copy(b) # 人工变量的地址
    x0 = np.zeros(n)
    init_basic = np.concatenate([x0,x1])
    return A_aug, c_aug, init_basic, M


# 模块3：单纯形法的迭代
def simplex_method(A, b, c, initial_basic,M):
    """
    单纯形法的迭代求解
    """
    if len(A.shape) == 1:
        A = A.reshape(1, -1)
    m, n = A.shape
    # 初始化基解
    x = initial_basic
    # non_basic_vars = np.arange(n)
    var_index = np.arange((n-m),n) 
    table = np.column_stack((A,b)) # 构建一张表,便于计算
    zs = np.zeros(n+1)

    # for i in range(n):
    #     zs[i] = c[i] - np.dot(c[var_index], table[:,i])
    zs[:-1] = c - np.dot(c[var_index], table[:, :-1])
    zs[n] = -np.dot(c[var_index], table[:,n])# 不去进行合并

    while True:
        # in_index = np.argmin(zs[:-1]) # 找到系数最小的 ,但是不能是最后一个
        # 选择入基变量：使用 Bland's Rule
        in_index = -1
        # in_index = np.argmin(zs[:-1])
        for i in range(n):  # 按下标顺序选择第一个 c_i < 0 的变量
            if zs[i] < 0: # 数值真的稳定吗 
                in_index = i
                break
        if in_index == -1:  # 所有 c_i >= 0，达到最优解
            x = np.zeros(n)
            x[var_index] = table[:, -1]
            return x, -zs[-1] # 返回结果
        in_index_0 = np.argmin(zs[:-1])
        in_index = random.choices([in_index, in_index_0], [0.3,0.7])[0] # 选择argmin的概率高
        # t = np.array([table[i,-1] / table[i,in_index] if(abs(table[i,in_index])>1e-6) else -np.inf  for i in range(m) ])
        # out_index = np.argmin(t) # var_index 中的, 以此为基础
        # 选择出基变量：使用 Bland's Rule
        # 计算最小比率：使用 Bland's Rule
        theta = np.inf
        out_index = -1
        for i in range(m):# 遍历一行
            if table[i, in_index] > 0:  # 避免除零和负值
                ratio = table[i, -1] / table[i, in_index]
                # 首先更新最小比率
                if ratio < theta:
                    theta = ratio
                    out_index = i
                # # 如果比率相等，则按下标顺序选择
                # elif abs(ratio - theta) < 1e-8 and var_index[i] < var_index[out_index]:
                #     out_index = i

        if out_index == -1:  # 无界解
            global No_unbounded_solution
            No_unbounded_solution += 1
            return x,0
            raise ValueError("线性规划问题无界")

        # 更新基变量索引
        var_index[out_index] = in_index

        # 消去出基变量对应行
        pivot = table[out_index, in_index]
        table[out_index, :] /= pivot  # 归一化当前行

        for i in range(m):
            if i != out_index:
                table[i, :] -= table[i, in_index] * table[out_index, :]  # 消元

        # 更新 zs
        # for i in range(n):
        #     zs[i] = c[i] - np.dot(c[var_index], table[:,i])
        zs[:-1] = c - np.dot(c[var_index], table[:, :-1])  # 更新目标函数系数
        zs[-1] = -np.dot(c[var_index], table[:, -1])  # 更新常数项

def read_input_file(input_file):
    # 读取 LP_input.in 文件
    with open(input_file, "r") as f:
        # 读取第一行，n 和 m
        n, m = map(int, f.readline().split())
        
        # 读取第二行，c 向量
        c = np.array(list(map(float, f.readline().split())),dtype=float)
        
        # 初始化 A 和 b
        A = np.zeros((n, m),dtype=float)
        b = np.zeros(n, dtype=float)
        
        # 读取增广矩阵的每一行
        for i in range(n):
            row = list(map(float, f.readline().split()))
            A[i] = row[:-1]  # 前 m 个数是矩阵 A 的一行
            b[i] = row[-1]   # 最后一个数是 b 的对应元素
        
    return A, b, c

def simplex_method_(A,b, c):
    # input_file = "LP_input.in"
    
    # 读取文件并获得 A, b, c
    # A, b, c = read_input_file(input_file)
    
    c , A, b = convert_to_standard_form(c, A, b)
    A, b = remove_redundant_constraints(A, b)
    len_x = A.shape[1] # 变量的长度
    A, c, init_basic,M = initialize_feasible_solution(A, b, c)
    # print(init_basic    )
    x, obj = simplex_method(A, b, c, init_basic,M)
    # print(x)
    # print(obj)
    if np.any(x[len_x:] > 1e-6):
        global No_feasible_solution 
        No_feasible_solution += 1
        return None
        raise ValueError("线性规划问题无可行解")
            



def generate_random_input(m):
    # m = random.randint(10, 200) # 随机生成 m，范围在 [10, 200] 之间
    n = m - random.randint(0, m // 3) # 随机生成 n，满足 n <= m 且 m - n <= m / 3
    return n, m

def generate_matrix_and_vectors(n, m):
    # 生成一个 n x m 的随机矩阵 A，矩阵元素在 [-10, 10] 范围内
    A = np.random.uniform(-10, 10, (n, m))
    # 生成一个 m 维的随机向量 x，元素在 [0, 10] 范围内
    x = np.random.uniform(0, 10, m)
    b = A @ x # 计算 b = A * x
    # 生成一个 m 维的随机向量 c，元素在 [-10, 10] 范围内
    c = np.random.uniform(-10, 10, m)
    # dot_product = np.dot(c, x) # 计算 c 和 x 的点积
    return A, b, c,



ts = list(range(10,201,10))
res = []
for i in ts:
    t = []
    for _ in range(20):# 重复20次
        temp = No_feasible_solution
        n,m  = generate_random_input(i)
        A,b,c = generate_matrix_and_vectors(n,m)
        start = time.time()
        simplex_method_(A,b,c)
        end = time.time()
        if temp != No_feasible_solution:
            continue
        t.append(end-start)
    res.append(np.mean(t))
    if i % 10 == 0:
        print(f"n = {i} is done")
print(f"没有可行解的个数为{No_feasible_solution}\n无界解的个数为{No_unbounded_solution}")

plt.xlabel('n')
plt.ylabel('时间')
plt.title('运行时间随问题范围的变化')

plt.plot(ts,res)
plt.show()

